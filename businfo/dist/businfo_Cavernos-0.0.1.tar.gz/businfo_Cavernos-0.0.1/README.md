# Infos Relative à l'app

Temps d'attentes entre chaque screen :
```
 5000ms
 puis 
 10000ms label + change_screen 2
 
    
```